package net.farrucho.openblocks.block;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.farrucho.openblocks.OpenBlocks;
import net.farrucho.openblocks.block.custom.ElevatorBlock;
import net.farrucho.openblocks.block.custom.ElevatorBlockEntity;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.function.Function;

public class OpenBlocksModBlocks {

    public static final class_2248 ELEVATOR_BLOCK = registerBlock(
            "elevator_block",
            ElevatorBlock::new,
            class_4970.class_2251.method_9630(class_2246.field_10446)
                    .method_9632(0.8f)
    );


    public static final class_2591<ElevatorBlockEntity> ELEVATOR_BLOCK_ENTITY =
            class_2378.method_10230(
                    class_7923.field_41181,
                    class_2960.method_60655(OpenBlocks.MOD_ID, "elevator_block_entity"),
                    FabricBlockEntityTypeBuilder.create(
                            ElevatorBlockEntity::new,
                            ELEVATOR_BLOCK
                    ).build()
            );


    private static class_2248 registerBlock(
            String name,
            Function<class_4970.class_2251, class_2248> factory,
            class_4970.class_2251 settings
    ) {
        class_2960 id = class_2960.method_60655(OpenBlocks.MOD_ID, name);

        class_5321<class_2248> key =
                class_5321.method_29179(class_7924.field_41254, id);

        class_2248 block = factory.apply(
                settings.method_63500(key)
        );

        registerBlockItem(name, block);

        return class_2378.method_39197(
                class_7923.field_41175,
                key,
                block
        );
    }


    private static class_1792 registerBlockItem(String name, class_2248 block) {
        class_2960 id = class_2960.method_60655(OpenBlocks.MOD_ID, name);

        class_5321<class_1792> key =
                class_5321.method_29179(class_7924.field_41197, id);

        class_1792 item = new class_1747(
                block,
                new class_1792.class_1793()
                        .method_63686(key)
        );

        class_2378.method_39197(
                class_7923.field_41178,
                key,
                item
        );

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40198)
                .register(entries -> {
                    entries.method_45421(item);
                });

        return item;
    }


    public static void registerModBlock() {
        OpenBlocks.LOGGER.debug(
                "Registando blocos para " + OpenBlocks.MOD_ID
        );
    }
}