package net.farrucho.openblocks.block.custom;

import net.minecraft.class_11791;
import net.minecraft.class_11954;

public class ElevatorBlockEntityRenderState extends class_11954 {

    public boolean hasCamouflage = false;
    public class_11791 movingBlock = new class_11791();

}