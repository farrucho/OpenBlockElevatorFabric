package net.farrucho.openblocks.block.custom;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_11791;
import net.minecraft.class_11954;
import net.minecraft.class_12075;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_5614;
import net.minecraft.class_827;

@Environment(EnvType.CLIENT)
public class ElevatorBlockEntityRenderer
        implements class_827<ElevatorBlockEntity, ElevatorBlockEntityRenderState> {

    public ElevatorBlockEntityRenderer(class_5614.class_5615 context) {
    }

    @Override
    public ElevatorBlockEntityRenderState method_74335() {
        return new ElevatorBlockEntityRenderState();
    }

    @Override
    public void updateRenderState(
            ElevatorBlockEntity entity,
            ElevatorBlockEntityRenderState state,
            float tickProgress,
            class_243 cameraPos,
            class_11683.class_11792 crumblingOverlay
    ) {
        class_11954.method_74399(
                entity,
                state,
                crumblingOverlay
        );

        class_1937 world = entity.method_10997();
        if (world == null) {
            return;
        }

        class_2680 camouflage = entity.getCamouflageState();

        // If there is no camouflage, flag it as false and return.
        // The chunk renderer will natively display the default elevator block.
        if (camouflage == null) {
            state.hasCamouflage = false;
            return;
        }

        state.hasCamouflage = true;
        class_11791 moving = new class_11791();

        moving.field_62247 = camouflage;
        moving.field_62249 = world;
        moving.field_62246 = entity.method_11016();
        moving.field_62245 = entity.method_11016();
        moving.field_62248 = world.method_23753(entity.method_11016());

        state.movingBlock = moving;
    }

    @Override
    public void render(
            ElevatorBlockEntityRenderState state,
            class_4587 matrices,
            class_11659 queue,
            class_12075 cameraState
    ) {
        if (state.hasCamouflage) {
            matrices.method_22903();

            // Shrunk from 0.002f to 0.0002f.
            // This micro-offset is enough to stop Z-fighting but keeps
            // the camouflage tucked safely inside the vanilla crumble effect.
            float offset = 0.0002f;
            matrices.method_46416(-offset, -offset, -offset);
            matrices.method_22905(1f + (offset * 2), 1f + (offset * 2), 1f + (offset * 2));

            queue.method_73485(
                    matrices,
                    state.movingBlock
            );

            matrices.method_22909();
        }
    }
}