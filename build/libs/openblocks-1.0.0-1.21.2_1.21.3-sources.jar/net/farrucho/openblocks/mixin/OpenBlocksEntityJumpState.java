package net.farrucho.openblocks.mixin;

import net.farrucho.openblocks.block.OpenBlocksModBlocks;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static net.farrucho.openblocks.block.custom.ElevatorBlockFunctions.goUp;
@Mixin(class_1309.class)
public class OpenBlocksEntityJumpState {
    @Inject(method = "jump()V", at = @At("HEAD"))
    private void injected(CallbackInfo info) {
        class_1309 entity = (class_1309)(Object)this;
        if (!(entity instanceof class_1657 p)) {
            return;
        }
        class_1937 world = p.method_37908();
        if (!world.method_8608()) {
            class_2338 blockpos = p.method_24515().method_10074();
            class_2680 blockState = world.method_8320(blockpos);

            if (blockState.method_27852(OpenBlocksModBlocks.ELEVATOR_BLOCK)
                    && !p.method_18276()) {
                goUp(blockpos, world, p);
            }
        }
    }
}