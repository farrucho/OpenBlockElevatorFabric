package net.farrucho.openblocks.block.custom;

import net.farrucho.openblocks.block.OpenBlocksModBlocks;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7923;
//import javax.annotation.Nullable;
import org.jetbrains.annotations.Nullable;

/**
 * Holds the (optional) BlockState this elevator block is currently camouflaged as.
 * Because this stores a real BlockState instead of an index into a hardcoded list,
 * it works for ANY block in the game (or any other installed mod's blocks) with
 * zero extra registration.
 */
public class ElevatorBlockEntity extends class_2586 {

    private static final String CAMOUFLAGE_KEY = "CamouflageState";
    private static final String HAS_CAMOUFLAGE_KEY = "HasCamouflage";

    @Nullable
    private class_2680 camouflageState = null;

    public ElevatorBlockEntity(class_2338 pos, class_2680 state) {
        super(OpenBlocksModBlocks.ELEVATOR_BLOCK_ENTITY, pos, state);
    }

    @Nullable
    public class_2680 getCamouflageState() {
        return camouflageState;
    }

    /**
     * @param camouflageState the block appearance to copy, or null to clear the camouflage.
     */
    public void setCamouflageState(@Nullable class_2680 camouflageState) {
        this.camouflageState = camouflageState;
        sync();
    }

    /** Marks the block entity dirty for saving and pushes an update to nearby clients. */
    private void sync() {
        method_5431();
        if (field_11863 != null && !field_11863.field_9236) {
            field_11863.method_8413(field_11867, method_11010(), method_11010(), class_2248.field_31036);
        }
    }

    @Override
    protected void method_11007(class_2487 nbt) {
        super.method_11007(nbt);
        // IMPORTANT: always write something here, even when camouflageState is null. If this
        // method (combined with super.writeNbt, which writes nothing by default) produces a
        // fully empty NbtCompound, BlockEntityUpdateS2CPacket collapses that to "no data" and
        // the client never actually receives/applies the update - which is why clearing the
        // camo used to get stuck showing the last camo texture forever. This boolean guarantees
        // the compound always has at least one key, so "clear" updates actually reach the client.
        nbt.method_10556(HAS_CAMOUFLAGE_KEY, camouflageState != null);
        if (camouflageState != null) {
            nbt.method_10566(CAMOUFLAGE_KEY, class_2512.method_10686(camouflageState));
        }
    }

    @Override
    public void method_11014(class_2487 nbt) {
        super.method_11014(nbt);
        class_2680 previous = camouflageState;
        if (nbt.method_10573(CAMOUFLAGE_KEY, class_2520.field_33260)) {
            //BlockState state = NbtHelper.toBlockState(nbt.getCompound(CAMOUFLAGE_KEY));
            class_2680 state = class_2512.method_10681(
                    class_7923.field_41175.method_46771(),
                    nbt.method_10562(CAMOUFLAGE_KEY)
            );
            // NbtHelper.toBlockState falls back to Blocks.AIR if the stored block id
            // can't be resolved (e.g. the camo block's mod was removed) - treat that as "no camo".
            camouflageState = state.method_26215() ? null : state;
        } else {
            camouflageState = null;
        }
        if (!java.util.Objects.equals(previous, camouflageState)) {
            String side = (field_11863 != null && field_11863.field_9236) ? "CLIENT" : "SERVER/unknown";
            //net.farrucho.openblocks.OpenBlocks.LOGGER.info("[Elevator DEBUG] ({}) readNbt at {} -> camouflageState = {}", side, pos, camouflageState);
        }
    }

    // --- Client sync boilerplate: sends the full NBT (including our camo state) whenever
    // the block entity is updated, and whenever a chunk is sent to a client. ---

    @Nullable
    @Override
    public class_2622 method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887() {
        return method_38244();
    }
}