package net.farrucho.openblocks.block.custom;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.farrucho.openblocks.OpenBlocks;
import net.farrucho.openblocks.block.OpenBlocksModBlocks;
import net.minecraft.class_1937;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4696;
import net.minecraft.class_5614;
import net.minecraft.class_5819;
import net.minecraft.class_827;

/**
 * Renders the elevator block as whatever block it's camouflaged as. Because this asks
 * Minecraft's own BlockRenderManager to draw the target BlockState directly, it automatically
 * gets the correct texture, tint (e.g. grass/leaves color), and lighting/ambient occlusion for
 * ANY block - no per-block model/texture setup required on our end.
 */
@Environment(EnvType.CLIENT)
public class ElevatorBlockEntityRenderer implements class_827<ElevatorBlockEntity> {

    private final class_5819 random = class_5819.method_43047();
    private class_2680 lastLoggedState = null;
    private boolean loggedConstruction = false;

    public ElevatorBlockEntityRenderer(class_5614.class_5615 context) {
        // Fires once when Fabric wires up the renderer - if this line never appears in the log,
        // BlockEntityRendererRegistry.register() never ran / never matched this BlockEntityType.
        OpenBlocks.LOGGER.info("[Elevator DEBUG] ElevatorBlockEntityRenderer constructed - registration is working.");
    }

    @Override
    public void render(ElevatorBlockEntity entity, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        class_1937 world = entity.method_10997();
        if (world == null) {
            return;
        }

        class_2680 renderState = entity.getCamouflageState();

        if (renderState == null) {
            // No camouflage applied yet - show the elevator block's own plain look. This is
            // safe to draw here (and won't cause the earlier flicker) because ElevatorBlock's
            // getRenderType() returns INVISIBLE, so the chunk mesh contributes zero geometry
            // of its own - this BER call is now the ONLY thing drawing the block, camo or not.
            renderState = OpenBlocksModBlocks.ELEVATOR_BLOCK.method_9564();
        }

        if (!java.util.Objects.equals(renderState, lastLoggedState)) {
            OpenBlocks.LOGGER.info("[Elevator DEBUG] render() at {} now drawing state = {}", entity.method_11016(), renderState);
            lastLoggedState = renderState;
        }

        try {
            matrices.method_22903();

            class_310 client = class_310.method_1551();
            net.minecraft.class_776 blockRenderManager = client.method_1541();
            net.minecraft.class_1087 model = blockRenderManager.method_3349(renderState);

            // NOTE: we deliberately do NOT use blockRenderManager.renderBlock(...) here. That
            // convenience method checks renderState.getRenderType() internally and silently draws
            // nothing unless it equals BlockRenderType.MODEL. Since ElevatorBlock.getRenderType()
            // always returns INVISIBLE (that's what stops the chunk mesh double-drawing our
            // camouflage), the elevator's OWN default state would also get vetoed by that same
            // check when there's no camo, rendering as fully transparent. Calling the lower-level
            // BlockModelRenderer directly (the same one the chunk mesher itself calls) skips that
            // gate entirely, so it draws regardless of what getRenderType() reports.
            blockRenderManager.method_3350().method_3374(
                    world,
                    model,
                    renderState,
                    entity.method_11016(),
                    matrices,
                    vertexConsumers.getBuffer(class_4696.method_23679(renderState)),
                    true,
                    random,
                    renderState.method_26190(entity.method_11016()),
                    overlay
            );

            matrices.method_22909();
        } catch (Throwable t) {
            // Minecraft normally swallows exceptions thrown inside a BlockEntityRenderer without
            // crashing, which makes rendering bugs like this invisible unless we log them ourselves.
            OpenBlocks.LOGGER.error("[Elevator DEBUG] renderBlock threw an exception at " + entity.method_11016(), t);
        }
    }
}