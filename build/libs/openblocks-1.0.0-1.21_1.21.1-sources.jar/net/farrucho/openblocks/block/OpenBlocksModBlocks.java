package net.farrucho.openblocks.block;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.farrucho.openblocks.OpenBlocks;
import net.farrucho.openblocks.block.custom.ElevatorBlock;
import net.farrucho.openblocks.block.custom.ElevatorBlockEntity;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public class OpenBlocksModBlocks {

    public static final class_2248 ELEVATOR_BLOCK = registerBlock(
            "elevator_block",
            new ElevatorBlock(
                    FabricBlockSettings.copyOf(class_2246.field_10446)
                            .method_9632(0.8f)
            )
    );

    public static final class_2591<ElevatorBlockEntity> ELEVATOR_BLOCK_ENTITY = class_2378.method_10230(
            class_7923.field_41181,
            class_2960.method_60655(OpenBlocks.MOD_ID, "elevator_block_entity"),
            FabricBlockEntityTypeBuilder.create(ElevatorBlockEntity::new, ELEVATOR_BLOCK).build()
    );

    private static class_2248 registerBlock(String name, class_2248 block) {
        registerBlockItem(name, block);

        return class_2378.method_10230(
                class_7923.field_41175,
                class_2960.method_60655(OpenBlocks.MOD_ID, name),
                block
        );
    }

    private static class_1792 registerBlockItem(String name, class_2248 block) {
        class_1792 item = class_2378.method_10230(
                class_7923.field_41178,
                class_2960.method_60655(OpenBlocks.MOD_ID, name),
                new class_1747(block, new  class_1792.class_1793())
        );

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40198).register(entries -> {
            entries.method_45421(item);
        });

        return item;
    }

    public static void registerModBlock() {
        OpenBlocks.LOGGER.debug("Registando blocos para " + OpenBlocks.MOD_ID);
    }
}