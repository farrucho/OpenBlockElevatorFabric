package net.farrucho.openblocks.block.custom;

import net.farrucho.openblocks.block.OpenBlocksModBlocks;
import net.farrucho.openblocks.config.ModConfigs;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class ElevatorBlockFunctions {
    static int RANGE = ModConfigs.ELEVATOR_BLOCK_RANGE;

    public static boolean goUp(class_2338 bp, class_1937 world, class_1657 player){
        class_2248 CURRENT_ELEVATOR_TYPE_BLOCK = world.method_8320(new class_2338(bp.method_10263(),bp.method_10264(),bp.method_10260())).method_26204();


        //////////player.sendMessage(Text.of(CURRENT_ELEVATOR_TYPE_BLOCK.toString()),true);

        for(int y = bp.method_10264() + 2; y <= bp.method_10264() + RANGE + 1; ++y){//offset 25 em relacao a cabeca do player
            class_2338 currentBlockPos = new class_2338(bp.method_10263(),y,bp.method_10260());

            if(world.method_8320(currentBlockPos).method_27852(CURRENT_ELEVATOR_TYPE_BLOCK) &&
                    world.method_8320(new class_2338(bp.method_10263(),y+1,bp.method_10260())).method_27852(class_2246.field_10124) &&
                    world.method_8320(new class_2338(bp.method_10263(),y+2,bp.method_10260())).method_27852(class_2246.field_10124)){
                class_2338 destination = new class_2338(bp.method_10263(), y+1, bp.method_10260());
                playTeleportEffects(world, bp, destination);
                //player.setPos(bp.getX(), y+1, bp.getZ());
                player.method_20620(bp.method_10263() + 0.5, y+1, bp.method_10260() + 0.5);
                return true;
            }
        }
        return false;
    }

    public static boolean goDown(class_2338 bp, class_1937 world, class_1657 player){
        class_2248 CURRENT_ELEVATOR_TYPE_BLOCK = world.method_8320(new class_2338(bp.method_10263(),bp.method_10264(),bp.method_10260())).method_26204();
        //////////player.sendMessage(Text.of(CURRENT_ELEVATOR_TYPE_BLOCK.toString()),true);


        for(int y = bp.method_10264() - 2; y >= bp.method_10264() - RANGE - 1; --y){
            class_2338 currentBlockPos = new class_2338(bp.method_10263(),y,bp.method_10260());

            //player.sendMessage(Text.of( "y = " + y + world.getBlockState(currentBlockPos).isOf(OpenBlocksModBlocks.ELEVATOR_BLOCK)),true);
            if(world.method_8320(currentBlockPos).method_27852(CURRENT_ELEVATOR_TYPE_BLOCK) &&
                    world.method_8320(new class_2338(bp.method_10263(),y+1,bp.method_10260())).method_27852(class_2246.field_10124) &&
                    world.method_8320(new class_2338(bp.method_10263(),y+2,bp.method_10260())).method_27852(class_2246.field_10124)){
                class_2338 destination = new class_2338(bp.method_10263(), y+1, bp.method_10260());
                playTeleportEffects(world, bp, destination);
                player.method_20620(bp.method_10263() + 0.5, y+1, bp.method_10260() + 0.5);
                player.method_5660(false);
                //player.sendMessage(Text.of("Tp para baixo feito"),true);
                return true;
            }
        }
        return false;
    }

    /**
     * Plays a small departure/arrival cue - a piston-style whoosh at the spot the player left,
     * a softer settling thump where they land, plus a cloud of particles at both ends.
     */
    private static void playTeleportEffects(class_1937 world, class_2338 from, class_2338 to){
        world.method_43128(null, from.method_10263() + 0.5, from.method_10264() + 0.5, from.method_10260() + 0.5,
                class_3417.field_15134, class_3419.field_15245, 0.5f, 1.4f);
        world.method_43128(null, to.method_10263() + 0.5, to.method_10264() + 0.5, to.method_10260() + 0.5,
                class_3417.field_15228, class_3419.field_15245, 0.5f, 1.4f);

        spawnTeleportParticles(world, from);
        spawnTeleportParticles(world, to);
    }

    private static void spawnTeleportParticles(class_1937 world, class_2338 pos){
        double x = pos.method_10263() + 0.5;
        double y = pos.method_10264() + 0.15;
        double z = pos.method_10260() + 0.5;

        // World#addParticle is a client-only no-op; on the logical server we have to use
        // ServerWorld#spawnParticles so the packet actually gets sent to nearby players.
        if (world instanceof class_3218 serverWorld) {
            serverWorld.method_14199(class_2398.field_11204, x, y, z, 14, 0.3, 0.1, 0.3, 0.02);
            serverWorld.method_14199(class_2398.field_11207, x, y + 0.2, z, 6, 0.2, 0.25, 0.2, 0.01);
        } else {
            world.method_8406(class_2398.field_11204, x, y, z, 0, 0.05, 0);
        }
    }

}