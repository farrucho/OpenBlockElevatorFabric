package net.farrucho.openblocks.block.custom;

import net.farrucho.openblocks.block.OpenBlocksModBlocks;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
//import javax.annotation.Nullable;
import org.jetbrains.annotations.Nullable;

/**
 * Holds the (optional) BlockState this elevator block is currently camouflaged as.
 * Because this stores a real BlockState instead of an index into a hardcoded list,
 * it works for ANY block in the game (or any other installed mod's blocks) with
 * zero extra registration.
 */
public class ElevatorBlockEntity extends class_2586 {

    private static final String CAMOUFLAGE_KEY = "CamouflageState";
    private static final String HAS_CAMOUFLAGE_KEY = "HasCamouflage";

    @Nullable
    private class_2680 camouflageState = null;

    public ElevatorBlockEntity(class_2338 pos, class_2680 state) {
        super(OpenBlocksModBlocks.ELEVATOR_BLOCK_ENTITY, pos, state);
    }

    @Nullable
    public class_2680 getCamouflageState() {
        return camouflageState;
    }

    /**
     * @param camouflageState the block appearance to copy, or null to clear the camouflage.
     */
    public void setCamouflageState(@Nullable class_2680 camouflageState) {
        this.camouflageState = camouflageState;
        sync();
    }

    /** Marks the block entity dirty for saving and pushes an update to nearby clients. */
    private void sync() {
        method_5431();
        if (field_11863 != null && !field_11863.field_9236) {
            field_11863.method_8413(field_11867, method_11010(), method_11010(), class_2248.field_31036);
        }
    }

    @Override
    protected void method_11007(class_11372 view) {
        super.method_11007(view);

        view.method_71472(HAS_CAMOUFLAGE_KEY, camouflageState != null);

        if (camouflageState != null) {
            view.method_71468(CAMOUFLAGE_KEY, class_2680.field_24734, camouflageState);
        }
    }

    @Override
    protected void method_11014(class_11368 view) {
        super.method_11014(view);

        camouflageState = null;

        if (view.method_71433(HAS_CAMOUFLAGE_KEY, false)) {
            camouflageState = view.method_71426(CAMOUFLAGE_KEY, class_2680.field_24734).orElse(null);

            if (camouflageState != null && camouflageState.method_26215()) {
                camouflageState = null;
            }
        }
    }

    // --- Client sync boilerplate: sends the full NBT (including our camo state) whenever
    // the block entity is updated, and whenever a chunk is sent to a client. ---

    @Nullable
    @Override
    public class_2622 method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registries) {
        return method_38244(registries);
    }
}