package net.farrucho.openblocks.block.custom;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.farrucho.openblocks.OpenBlocks;
import net.farrucho.openblocks.block.OpenBlocksModBlocks;
import net.minecraft.class_1087;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_776;
import net.minecraft.class_827;

/**
 * Renders the elevator block as whatever block it's camouflaged as. Because this asks
 * Minecraft's own block model renderer to draw the target BlockState directly (with real world
 * context), it automatically gets the correct texture, tint (e.g. grass/leaves color), and
 * lighting/ambient occlusion for ANY block - no per-block model/texture setup required on our end.
 */
@Environment(EnvType.CLIENT)
public class ElevatorBlockEntityRenderer implements class_827<ElevatorBlockEntity> {

    private class_2680 lastLoggedState = null;

    public ElevatorBlockEntityRenderer(class_5614.class_5615 context) {
        // Fires once when Fabric wires up the renderer
        //OpenBlocks.LOGGER.info("[Elevator DEBUG] ElevatorBlockEntityRenderer constructed - registration is working.");
    }

    @Override
    public void render(
            ElevatorBlockEntity entity,
            float tickDelta,
            class_4587 matrices,
            class_4597 vertexConsumers,
            int light,
            int overlay,
            class_243 cameraPos
    ) {
        class_1937 world = entity.method_10997();
        if (world == null) {
            return;
        }

        class_2680 renderState = entity.getCamouflageState();

        if (renderState == null) {
            // No camouflage applied yet - show the elevator block's own plain look.
            renderState = OpenBlocksModBlocks.ELEVATOR_BLOCK.method_9564();
        }

        class_2338 pos = entity.method_11016();

        if (!java.util.Objects.equals(renderState, lastLoggedState)) {
            //OpenBlocks.LOGGER.info("[Elevator DEBUG] render() at {} now drawing state = {}", pos, renderState);
            lastLoggedState = renderState;
        }

        try {
            matrices.method_22903();

            class_310 client = class_310.method_1551();
            class_776 blockRenderManager = client.method_1541();
            class_1087 model = blockRenderManager.method_3349(renderState);

            // Updated parameters for 1.21.4 / 1.21.5:
            // - Passes vertexConsumers directly (instead of getBuffer(...))
            // - Removed random parameter
            blockRenderManager.method_3350().render(
                    world,
                    model,
                    renderState,
                    pos,
                    matrices,
                    vertexConsumers,
                    true,
                    renderState.method_26190(pos),
                    overlay
            );

            matrices.method_22909();
        } catch (Throwable t) {
            //OpenBlocks.LOGGER.error("[Elevator DEBUG] render threw an exception at " + pos, t);
        }
    }
}