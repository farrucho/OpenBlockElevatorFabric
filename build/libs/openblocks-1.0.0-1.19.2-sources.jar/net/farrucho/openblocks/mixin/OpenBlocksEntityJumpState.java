package net.farrucho.openblocks.mixin;

import net.farrucho.openblocks.block.OpenBlocksModBlocks;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2374;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static net.farrucho.openblocks.block.custom.ElevatorBlockFunctions.goUp;

@Mixin(class_1657.class)
public class OpenBlocksEntityJumpState {
    @Inject(at = @At("HEAD"), method = "jump()V")
    private void injected(CallbackInfo info) {
        class_1657 p = (class_1657)(Object)this;
        //World world = p.getWorld();
        class_1937 world = p.method_5770();
        if(!p.field_6002.method_8608()){
            //p.sendMessage(Text.literal("player jumped"));
            class_2374 posUnder = new class_2374() {
                @Override
                public double method_10216() {
                    return p.method_23317();
                }

                @Override
                public double method_10214() {
                    return p.method_23318() - 1;
                }

                @Override
                public double method_10215() {
                    return p.method_23321();
                }
            };

            class_2338 blockpos = new class_2338(posUnder);
            //Block block = world.getBlockState(blockpos).getBlock();
            class_2680 blockState = world.method_8320(blockpos);
            if(blockState.method_27852(OpenBlocksModBlocks.ELEVATOR_BLOCK) && !p.method_18276()){
                //p.sendMessage(Text.literal("Elevador para cima"));
                goUp(blockpos, world, p);
            }
        }
    }
}