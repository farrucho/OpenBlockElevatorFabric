package net.farrucho.openblocks.block;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.farrucho.openblocks.OpenBlocks;
import net.farrucho.openblocks.block.custom.ElevatorBlock;
import net.farrucho.openblocks.block.custom.ElevatorBlockEntity;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3614;

public class OpenBlocksModBlocks {

    public static final class_2248 ELEVATOR_BLOCK = registerBlock("elevator_block", new ElevatorBlock(FabricBlockSettings.method_9637(class_3614.field_15931).method_36557(0.8f).method_9626(class_2498.field_11543)), class_1761.field_7914);
    //1.19.3 itemgroups
    //1.19.2 itemgroup

    public static final class_2591<ElevatorBlockEntity> ELEVATOR_BLOCK_ENTITY = class_2378.method_10230(
            class_2378.field_11137,
            new class_2960(OpenBlocks.MOD_ID, "elevator_block_entity"),
            FabricBlockEntityTypeBuilder.create(ElevatorBlockEntity::new, ELEVATOR_BLOCK).build()
    );

    private static class_2248 registerBlock(String name, class_2248 block, class_1761 group){
        registerBlockItem(name, block, group);
        //return Registry.register(Registries.BLOCK, new Identifier(OpenBlocks.MOD_ID, name), block); // 1.19.3
        return class_2378.method_10230(class_2378.field_11146, new class_2960(OpenBlocks.MOD_ID, name), block); // 1.19.2
    }

    private static class_1792 registerBlockItem(String name, class_2248 block, class_1761 group) {
        /*return Registry.register(Registries.ITEM, new Identifier(OpenBlocks.MOD_ID, name), new BlockItem(block, new FabricItemSettings()));*/
        return class_2378.method_10230(class_2378.field_11142, new class_2960(OpenBlocks.MOD_ID, name), new class_1747(block, new FabricItemSettings().method_7892(class_1761.field_7914)));
    }


    public static void registerModBlock() {
        OpenBlocks.LOGGER.debug("Registando blocos para " + OpenBlocks.MOD_ID);
    }
}