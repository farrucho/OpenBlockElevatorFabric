package net.farrucho.openblocks.block.custom;

import net.farrucho.openblocks.OpenBlocks;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2464;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2682;
import net.minecraft.class_3965;
import net.minecraft.class_4970;

import static net.farrucho.openblocks.block.custom.ElevatorBlockFunctions.goDown;

public class ElevatorBlock extends class_2248 implements class_2343 {

    public ElevatorBlock(class_4970.class_2251 settings) {
        super(settings);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new ElevatorBlockEntity(pos, state);
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        // All visuals are drawn by ElevatorBlockEntityRenderer (same technique vanilla uses
        // for the moving piston block entity) - MODEL would ALSO bake/draw this block's own
        // model into the chunk mesh every frame, on top of whatever the BER draws, causing
        // z-fighting/flicker between the two overlapping full-cube geometries. INVISIBLE means
        // this block contributes zero geometry of its own; the BER is 100% responsible for visuals.
        return class_2464.field_11455;
    }

    @Override
    public void method_9591(class_1937 world, class_2338 blockpos, class_2680 state, class_1297 entity) {
        if (entity.method_18276() && entity.method_31747() && !world.method_8608()) {
            class_1657 p = (class_1657) entity;
            goDown(blockpos, world, p);
        }
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (world.field_9236) {
            // Let the server handle the actual state change; still "succeed" client-side
            // so the swing animation plays and the interaction isn't passed further down.
            return class_1269.field_5812;
        }

        class_2586 be = world.method_8321(pos);
        if (!(be instanceof ElevatorBlockEntity)) {
            //player.sendMessage(Text.literal("[Elevator DEBUG] No ElevatorBlockEntity at this position!"), true);
            //OpenBlocks.LOGGER.warn("[Elevator DEBUG] getBlockEntity returned {} at {}", be, pos);
            return class_1269.field_5811;
        }
        ElevatorBlockEntity elevatorEntity = (ElevatorBlockEntity) be;

        class_1799 heldStack = player.method_5998(hand);
        class_1792 itemUsed = heldStack.method_7909();

        if (!(itemUsed instanceof class_1747)) {
            // Not holding a block - nothing to camouflage with, let other interactions proceed.
            //player.sendMessage(Text.literal("[Elevator DEBUG] Not holding a BlockItem (holding: " + itemUsed + ")"), true);
            return class_1269.field_5811;
        }
        class_1747 heldBlockItem = (class_1747) itemUsed;
        class_2248 clickedBlock = heldBlockItem.method_7711();

        // Right-clicking with the Elevator Block itself resets to the default look.
        if (clickedBlock == this) {
            elevatorEntity.setCamouflageState(null);
            //player.sendMessage(Text.literal("[Elevator DEBUG] Camouflage cleared (server-side)."), true);
            return class_1269.field_5812;
        }

        class_2680 camouflageState = clickedBlock.method_9564();

        // Only full cube blocks make sense as camouflage (stairs/slabs/etc. would look broken).
        boolean isFullCube = camouflageState.method_26234(class_2682.field_12294, class_2338.field_10980);
        if (!isFullCube) {
            player.method_7353(class_2561.method_43471("message.openblocks.elevator_needs_full_cube"), true);
            //OpenBlocks.LOGGER.info("[Elevator DEBUG] Rejected {} - not a full cube", Registry.BLOCK.getId(clickedBlock));
            return class_1269.field_5814;
        }

        elevatorEntity.setCamouflageState(camouflageState);
        //player.sendMessage(Text.literal("Camouflage SET to " + Registry.BLOCK.getId(clickedBlock)), true);
        //OpenBlocks.LOGGER.info("[Elevator DEBUG] setCamouflageState called with {} at {}", camouflageState, pos);
        return class_1269.field_5812;
    }
}